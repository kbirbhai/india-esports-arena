package com.example.model

data class Tournament(
    val id: String,
    val title: String,
    val game: String = "Free Fire MAX",
    val format: String = "Squad", // Squad, Duo, Solo
    val teamLimit: Int = 48,
    val registeredCount: Int = 32,
    val status: String = "Upcoming", // Upcoming, Ongoing, Completed
    val startDate: String,
    val map: String = "Bermuda",
    val prizePool: String = "Trophy & Hall of Fame",
    val entryFee: String = "FREE",
    val rules: String = "Standard FF eSports Rules. No hack/emulator allowed. 4 players per squad.",
    val bannerDrawableRes: Int? = null,
    val registeredTeamNames: MutableList<String> = mutableListOf()
)

data class MatchTeamResult(
    val rank: Int,
    val teamName: String,
    val killPoints: Int,
    val placementPoints: Int,
    val totalPoints: Int = killPoints + placementPoints,
    val booyah: Boolean = rank == 1
)

data class Match(
    val id: String,
    val tournamentId: String? = null,
    val tournamentTitle: String = "Community Scrims",
    val matchName: String,
    val game: String = "Free Fire MAX",
    val format: String = "Squad",
    val map: String = "Bermuda",
    val startTime: String,
    val status: String = "Upcoming", // Upcoming, Live, Completed
    val roomId: String = "ROOM-88219",
    val roomPassword: String = "FF7788",
    val streamUrl: String = "https://youtube.com/live/freefireindia",
    val results: List<MatchTeamResult> = emptyList()
)

data class Team(
    val id: String,
    val name: String,
    val tag: String,
    val captainName: String,
    val membersCount: Int = 4,
    val winRate: String = "68%",
    val matchesPlayed: Int = 42,
    val totalWins: Int = 18,
    val totalKills: Int = 210,
    val totalPoints: Int = 390,
    val rank: Int = 1,
    val rankChange: String = "+1",
    val members: List<String> = listOf("Player1", "Player2", "Player3", "Player4"),
    val matchHistorySummary: List<String> = listOf("1st place - FF Winter Clash", "2nd place - Squad Scrims #110")
)

data class Player(
    val id: String,
    val name: String,
    val inGameName: String,
    val freeFireUid: String,
    val rankBadge: String = "Grandmaster", // Grandmaster, Heroic, Diamond
    val matchesPlayed: Int = 85,
    val wins: Int = 34,
    val kills: Int = 290,
    val kdRatio: Float = 4.2f,
    val headshotPercent: String = "58%",
    val role: String = "Fragger", // Fragger, Captain, Sniper, Support
    val favoriteTeam: String = "Total Gaming eSports",
    val rank: Int = 1,
    val rankChange: String = "0"
)

data class PracticeMatch(
    val id: String,
    val title: String,
    val map: String = "Bermuda",
    val mode: String = "Free Squad Scrim",
    val time: String,
    val slotsMax: Int = 12,
    val slotsFilled: Int = 8,
    val status: String = "Upcoming", // Upcoming, Live, Completed
    val roomId: String = "PRAC-55110",
    val roomPassword: String = "1234",
    val hostName: String = "IndiaEsports Host"
)

data class NotificationItem(
    val id: String,
    val title: String,
    val message: String,
    val timestamp: String,
    val category: String = "Match", // Match, Tournament, Result, Practice
    val isRead: Boolean = false
)

data class UserProfile(
    val username: String = "ProGamer_IN",
    val inGameName: String = "SK_Saber",
    val freeFireUid: String = "782910432",
    val rankBadge: String = "Heroic",
    val matchesPlayed: Int = 54,
    val totalWins: Int = 19,
    val totalKills: Int = 178,
    val headshotPercent: String = "49%",
    val favoriteTeam: String = "Total Gaming eSports",
    val registeredTournaments: MutableList<String> = mutableListOf("Free Fire India Cup 2026")
)
