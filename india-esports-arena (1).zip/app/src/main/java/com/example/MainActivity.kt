package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.EsportsRepository
import com.example.model.*
import com.example.ui.components.EsportsHeader
import com.example.ui.dialogs.*
import com.example.ui.navigation.EsportsBottomNavigationBar
import com.example.ui.screens.*
import com.example.ui.theme.EsportsDarkBg
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                MainAppScreen()
            }
        }
    }
}

@Composable
fun MainAppScreen() {
    var currentScreen by remember { mutableStateOf("HOME") }

    // Repository state flows
    val tournaments by EsportsRepository.tournaments.collectAsStateWithLifecycle()
    val matches by EsportsRepository.matches.collectAsStateWithLifecycle()
    val teams by EsportsRepository.teams.collectAsStateWithLifecycle()
    val players by EsportsRepository.players.collectAsStateWithLifecycle()
    val practiceMatches by EsportsRepository.practiceMatches.collectAsStateWithLifecycle()
    val notifications by EsportsRepository.notifications.collectAsStateWithLifecycle()
    val userProfile by EsportsRepository.userProfile.collectAsStateWithLifecycle()

    // Dialog state handlers
    var selectedTournamentForDetail by remember { mutableStateOf<Tournament?>(null) }
    var selectedMatchForDetail by remember { mutableStateOf<Match?>(null) }
    var selectedTeamForDetail by remember { mutableStateOf<Team?>(null) }
    var selectedPlayerForDetail by remember { mutableStateOf<Player?>(null) }
    var tournamentToRegister by remember { mutableStateOf<Tournament?>(null) }
    var showCreatePracticeDialog by remember { mutableStateOf(false) }

    val unreadNotifsCount = notifications.count { !it.isRead }

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .testTag("main_app_scaffold"),
        containerColor = EsportsDarkBg,
        topBar = {
            EsportsHeader(
                unreadCount = unreadNotifsCount,
                onNotificationClick = { currentScreen = "NOTIFICATIONS" },
                onAdminClick = { currentScreen = "ADMIN" },
                currentScreenTitle = currentScreen
            )
        },
        bottomBar = {
            EsportsBottomNavigationBar(
                currentRoute = currentScreen,
                onNavigate = { route -> currentScreen = route }
            )
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .background(EsportsDarkBg)
        ) {
            when (currentScreen) {
                "HOME" -> HomeScreen(
                    tournaments = tournaments,
                    matches = matches,
                    practiceMatches = practiceMatches,
                    topPlayers = players,
                    onSelectTournament = { selectedTournamentForDetail = it },
                    onSelectMatch = { selectedMatchForDetail = it },
                    onRegisterTournament = { tournamentToRegister = it },
                    onNavigateSection = { route -> currentScreen = route }
                )
                "TOURNAMENTS" -> TournamentsScreen(
                    tournaments = tournaments,
                    onSelectTournament = { selectedTournamentForDetail = it },
                    onRegisterTournament = { tournamentToRegister = it }
                )
                "MATCHES" -> MatchesScreen(
                    matches = matches,
                    onSelectMatch = { selectedMatchForDetail = it }
                )
                "LEADERBOARD" -> LeaderboardScreen(
                    teams = teams,
                    players = players
                )
                "TEAMS" -> TeamsScreen(
                    teams = teams,
                    onSelectTeam = { selectedTeamForDetail = it }
                )
                "PLAYERS" -> PlayersScreen(
                    players = players,
                    onSelectPlayer = { selectedPlayerForDetail = it }
                )
                "PRACTICE" -> PracticeScreen(
                    practiceMatches = practiceMatches,
                    onJoinPractice = { EsportsRepository.joinPracticeMatch(it.id) },
                    onCreatePracticeClick = { showCreatePracticeDialog = true }
                )
                "PROFILE" -> ProfileScreen(
                    userProfile = userProfile,
                    onSaveProfile = { uname, ign, uid, badge, favTeam ->
                        EsportsRepository.updateUserProfile(uname, ign, uid, badge, favTeam)
                    }
                )
                "NOTIFICATIONS" -> NotificationsScreen(
                    notifications = notifications,
                    onMarkRead = { id -> EsportsRepository.markNotificationRead(id) },
                    onClearAll = { EsportsRepository.clearNotifications() }
                )
                "ADMIN" -> AdminScreen(
                    tournaments = tournaments,
                    matches = matches,
                    onCreateTournament = { title, game, format, slots, date, map, reward, rules ->
                        EsportsRepository.addTournament(title, game, format, slots, date, map, reward, rules)
                    },
                    onCreateMatch = { tourTitle, matchName, format, map, time, roomId, roomPass, streamUrl ->
                        EsportsRepository.createMatch(tourTitle, matchName, format, map, time, roomId, roomPass, streamUrl)
                    },
                    onUpdateScores = { matchId, results, setCompleted ->
                        EsportsRepository.updateMatchScores(matchId, results, setCompleted)
                    },
                    onAddTeam = { name, tag, captain ->
                        EsportsRepository.addTeam(name, tag, captain, listOf("$captain (Captain)", "Fragger", "Sniper", "Support"))
                    },
                    onBroadcast = { title, message, category ->
                        EsportsRepository.sendNotification(title, message, category)
                    }
                )
            }
        }
    }

    // Interactive Dialog Overlays
    selectedTournamentForDetail?.let { tournament ->
        TournamentDetailDialog(
            tournament = tournament,
            onDismiss = { selectedTournamentForDetail = null },
            onRegisterClick = {
                selectedTournamentForDetail = null
                tournamentToRegister = tournament
            }
        )
    }

    selectedMatchForDetail?.let { match ->
        MatchDetailDialog(
            match = match,
            onDismiss = { selectedMatchForDetail = null }
        )
    }

    selectedTeamForDetail?.let { team ->
        TeamDetailDialog(
            team = team,
            onDismiss = { selectedTeamForDetail = null }
        )
    }

    selectedPlayerForDetail?.let { player ->
        PlayerDetailDialog(
            player = player,
            onDismiss = { selectedPlayerForDetail = null }
        )
    }

    tournamentToRegister?.let { tournament ->
        RegisterTeamDialog(
            tournamentTitle = tournament.title,
            onDismiss = { tournamentToRegister = null },
            onSubmit = { squadName ->
                EsportsRepository.registerTeamForTournament(tournament.id, squadName)
            }
        )
    }

    if (showCreatePracticeDialog) {
        CreatePracticeDialog(
            onDismiss = { showCreatePracticeDialog = false },
            onSubmit = { title, map, mode, time, slotsMax, roomId, roomPass ->
                EsportsRepository.createPracticeMatch(title, map, mode, time, slotsMax, roomId, roomPass)
            }
        )
    }
}
