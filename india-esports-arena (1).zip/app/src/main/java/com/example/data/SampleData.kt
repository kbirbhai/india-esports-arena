package com.example.data

import com.example.model.*

object SampleData {

    val heroBannerResId: Int? = try {
        // Reference hero banner if available
        com.example.R.drawable.hero_banner_1786617372749
    } catch (e: Exception) {
        null
    }

    val initialTournaments = mutableListOf(
        Tournament(
            id = "t1",
            title = "Free Fire India Cup 2026",
            game = "Free Fire MAX",
            format = "Squad",
            teamLimit = 48,
            registeredCount = 44,
            status = "Ongoing",
            startDate = "Today, 7:00 PM IST",
            map = "Bermuda & Purgatory",
            prizePool = "Golden Trophy + Hall of Fame Title",
            entryFee = "FREE",
            rules = "Official FF India Tournament Rules. 6 Matches series. Point System: 1st=12, 2nd=9, 3rd=8, Kills=1pt.",
            bannerDrawableRes = heroBannerResId,
            registeredTeamNames = mutableListOf("Total Gaming eSports", "Orangutan Esports", "GodLike Esports", "Team Elite", "Chemist Esports", "Blind Esports")
        ),
        Tournament(
            id = "t2",
            title = "Winter War Championship Season 4",
            game = "Free Fire MAX",
            format = "Squad",
            teamLimit = 36,
            registeredCount = 28,
            status = "Upcoming",
            startDate = "Tomorrow, 8:00 PM IST",
            map = "Kalahari",
            prizePool = "Exclusive Community Crest & Certificate",
            entryFee = "FREE",
            rules = "Registration closes 1 hour before event. Room ID provided in Matches tab once checked-in.",
            registeredTeamNames = mutableListOf("Nigma Galaxy IN", "TSM India", "Total Gaming eSports")
        ),
        Tournament(
            id = "t3",
            title = "Daily Free Squad Practice Scrims #112",
            game = "Free Fire MAX",
            format = "Squad",
            teamLimit = 12,
            registeredCount = 12,
            status = "Live",
            startDate = "Live Now",
            map = "Alpine",
            prizePool = "Practice Points & Rank Boost",
            entryFee = "FREE",
            rules = "Instant Room ID access. Open for all verified squads.",
            registeredTeamNames = mutableListOf("Orangutan Esports", "GodLike Esports", "Team Elite", "Chemist Esports")
        ),
        Tournament(
            id = "t4",
            title = "Free Fire Solo Survival Clash",
            game = "Free Fire MAX",
            format = "Solo",
            teamLimit = 50,
            registeredCount = 50,
            status = "Completed",
            startDate = "Yesterday",
            map = "Bermuda",
            prizePool = "Solo MVP Crown",
            entryFee = "FREE",
            rules = "Single match survival battle.",
            registeredTeamNames = mutableListOf("Fabi", "Pahadi", "FozyAjay", "Vasiyo", "Mafia")
        )
    )

    val initialMatches = mutableListOf(
        Match(
            id = "m1",
            tournamentId = "t1",
            tournamentTitle = "Free Fire India Cup 2026",
            matchName = "Match 1 - Bermuda Battle",
            game = "Free Fire MAX",
            format = "Squad",
            map = "Bermuda",
            startTime = "Live Now",
            status = "Live",
            roomId = "ROOM-FF992",
            roomPassword = "771122(Live)",
            streamUrl = "https://youtube.com/live/freefireindia",
            results = listOf(
                MatchTeamResult(1, "Total Gaming eSports", killPoints = 14, placementPoints = 12, booyah = true),
                MatchTeamResult(2, "Orangutan Esports", killPoints = 9, placementPoints = 9, booyah = false),
                MatchTeamResult(3, "GodLike Esports", killPoints = 7, placementPoints = 8, booyah = false),
                MatchTeamResult(4, "Team Elite", killPoints = 5, placementPoints = 7, booyah = false),
                MatchTeamResult(5, "Nigma Galaxy IN", killPoints = 4, placementPoints = 6, booyah = false)
            )
        ),
        Match(
            id = "m2",
            tournamentId = "t1",
            tournamentTitle = "Free Fire India Cup 2026",
            matchName = "Match 2 - Purgatory Showdown",
            game = "Free Fire MAX",
            format = "Squad",
            map = "Purgatory",
            startTime = "Today, 8:15 PM IST",
            status = "Upcoming",
            roomId = "ROOM-FF993",
            roomPassword = "Unlocks at 8:00 PM",
            streamUrl = "https://youtube.com/live/freefireindia"
        ),
        Match(
            id = "m3",
            tournamentId = "t2",
            tournamentTitle = "Winter War Championship Season 4",
            matchName = "Quarter Finals - Kalahari",
            game = "Free Fire MAX",
            format = "Squad",
            map = "Kalahari",
            startTime = "Tomorrow, 8:30 PM IST",
            status = "Upcoming",
            roomId = "ROOM-WW102",
            roomPassword = "Assigned to Registered Teams",
            streamUrl = ""
        ),
        Match(
            id = "m4",
            tournamentId = "t4",
            tournamentTitle = "Free Fire Solo Survival Clash",
            matchName = "Finals - Solo Bermuda",
            game = "Free Fire MAX",
            format = "Solo",
            map = "Bermuda",
            startTime = "Yesterday, 9:00 PM IST",
            status = "Completed",
            roomId = "ROOM-SOLO1",
            roomPassword = "EXPIRED",
            results = listOf(
                MatchTeamResult(1, "Pahadi (Solo)", killPoints = 11, placementPoints = 12, booyah = true),
                MatchTeamResult(2, "Fabi (Solo)", killPoints = 8, placementPoints = 9, booyah = false),
                MatchTeamResult(3, "Vasiyo (Solo)", killPoints = 6, placementPoints = 8, booyah = false),
                MatchTeamResult(4, "Mafia (Solo)", killPoints = 4, placementPoints = 7, booyah = false)
            )
        )
    )

    val initialTeams = mutableListOf(
        Team(
            id = "team1",
            name = "Total Gaming eSports",
            tag = "TG",
            captainName = "FozyAjay",
            membersCount = 4,
            winRate = "74%",
            matchesPlayed = 58,
            totalWins = 26,
            totalKills = 340,
            totalPoints = 580,
            rank = 1,
            rankChange = "0",
            members = listOf("FozyAjay (IQL)", "Mafia (Fragger)", "Delete (Sniper)", "Vasiyo (Support)"),
            matchHistorySummary = listOf("Booyah! - FF India Cup Match 1", "1st Place - Winter Scrims #108", "2nd Place - FFMAX Pro Series")
        ),
        Team(
            id = "team2",
            name = "Orangutan Esports",
            tag = "OG",
            captainName = "Pahadi",
            membersCount = 4,
            winRate = "69%",
            matchesPlayed = 52,
            totalWins = 21,
            totalKills = 295,
            totalPoints = 510,
            rank = 2,
            rankChange = "+1",
            members = listOf("Pahadi (Captain/Sniper)", "Killer (Fragger)", "OldMonk (Fragger)", "Aadi (Support)"),
            matchHistorySummary = listOf("2nd Place - FF India Cup Match 1", "Booyah! - Night Scrims #111")
        ),
        Team(
            id = "team3",
            name = "GodLike Esports",
            tag = "GOD",
            captainName = "Shadow",
            membersCount = 4,
            winRate = "65%",
            matchesPlayed = 48,
            totalWins = 18,
            totalKills = 260,
            totalPoints = 465,
            rank = 3,
            rankChange = "-1",
            members = listOf("Shadow (IQL)", "Nayan (Fragger)", "Iconic (Sniper)", "Javagamer (Support)"),
            matchHistorySummary = listOf("3rd Place - FF India Cup Match 1", "1st Place - Squad Clash 2026")
        ),
        Team(
            id = "team4",
            name = "Team Elite",
            tag = "TE",
            captainName = "Fabi",
            membersCount = 4,
            winRate = "62%",
            matchesPlayed = 45,
            totalWins = 16,
            totalKills = 240,
            totalPoints = 420,
            rank = 4,
            rankChange = "+2",
            members = listOf("Fabi (IQL)", "Rockey (Fragger)", "Joshi (Sniper)", "Swastik (Support)")
        ),
        Team(
            id = "team5",
            name = "Chemist Esports",
            tag = "CHM",
            captainName = "Chemist_Boss",
            membersCount = 4,
            winRate = "58%",
            matchesPlayed = 40,
            totalWins = 13,
            totalKills = 210,
            totalPoints = 370,
            rank = 5,
            rankChange = "0",
            members = listOf("Chemist_Boss", "Nitro_FF", "Blaze", "Vortex")
        )
    )

    val initialPlayers = mutableListOf(
        Player(
            id = "p1",
            name = "Ajay Sharma",
            inGameName = "FozyAjay",
            freeFireUid = "891024881",
            rankBadge = "Grandmaster",
            matchesPlayed = 98,
            wins = 42,
            kills = 380,
            kdRatio = 4.8f,
            headshotPercent = "64%",
            role = "Captain / IQL",
            favoriteTeam = "Total Gaming eSports",
            rank = 1,
            rankChange = "0"
        ),
        Player(
            id = "p2",
            name = "Pahadi Gamer",
            inGameName = "Pahadi",
            freeFireUid = "712903412",
            rankBadge = "Grandmaster",
            matchesPlayed = 92,
            wins = 38,
            kills = 360,
            kdRatio = 4.5f,
            headshotPercent = "68%",
            role = "Sniper Specialist",
            favoriteTeam = "Orangutan Esports",
            rank = 2,
            rankChange = "+1"
        ),
        Player(
            id = "p3",
            name = "Aditya Singh",
            inGameName = "Mafia",
            freeFireUid = "619028441",
            rankBadge = "Grandmaster",
            matchesPlayed = 88,
            wins = 35,
            kills = 345,
            kdRatio = 4.3f,
            headshotPercent = "61%",
            role = "Entry Fragger",
            favoriteTeam = "Total Gaming eSports",
            rank = 3,
            rankChange = "-1"
        ),
        Player(
            id = "p4",
            name = "Kishan",
            inGameName = "Killer",
            freeFireUid = "551029311",
            rankBadge = "Heroic",
            matchesPlayed = 80,
            wins = 30,
            kills = 310,
            kdRatio = 4.1f,
            headshotPercent = "59%",
            role = "Fragger",
            favoriteTeam = "Orangutan Esports",
            rank = 4,
            rankChange = "+2"
        ),
        Player(
            id = "p5",
            name = "Vasiyo CR7",
            inGameName = "Vasiyo",
            freeFireUid = "901238491",
            rankBadge = "Heroic",
            matchesPlayed = 78,
            wins = 28,
            kills = 290,
            kdRatio = 3.9f,
            headshotPercent = "55%",
            role = "Support / IQL",
            favoriteTeam = "Total Gaming eSports",
            rank = 5,
            rankChange = "0"
        )
    )

    val initialPracticeMatches = mutableListOf(
        PracticeMatch(
            id = "prac1",
            title = "Free Squad Scrim Night #42",
            map = "Bermuda",
            mode = "Free Squad Practice",
            time = "Tonight, 9:00 PM IST",
            slotsMax = 12,
            slotsFilled = 9,
            status = "Upcoming",
            roomId = "PRAC-88120",
            roomPassword = "1234(Free)",
            hostName = "Arena Scrim Host"
        ),
        PracticeMatch(
            id = "prac2",
            title = "Duo Warmup Rush - Kalahari",
            map = "Kalahari",
            mode = "Duo Practice",
            time = "Live Now",
            status = "Live",
            slotsMax = 24,
            slotsFilled = 24,
            roomId = "DUO-9912",
            roomPassword = "DUO88",
            hostName = "IndiaEsports Admin"
        ),
        PracticeMatch(
            id = "prac3",
            title = "Solo Headshot Practice",
            map = "Purgatory",
            mode = "Solo Practice",
            time = "Today, 10:30 PM IST",
            slotsMax = 50,
            slotsFilled = 31,
            status = "Upcoming",
            roomId = "SOLO-4412",
            roomPassword = "FreeForRegistered",
            hostName = "Community Moderator"
        )
    )

    val initialNotifications = mutableListOf(
        NotificationItem(
            id = "n1",
            title = "Match Room ID Live!",
            message = "Room ID and Password for Free Fire India Cup Match 1 are now unlocked in Matches tab.",
            timestamp = "10 mins ago",
            category = "Match",
            isRead = false
        ),
        NotificationItem(
            id = "n2",
            title = "Booyah! Result Published",
            message = "Total Gaming eSports secured 1st place in Match 1 with 14 kills!",
            timestamp = "25 mins ago",
            category = "Result",
            isRead = false
        ),
        NotificationItem(
            id = "n3",
            title = "Practice Scrim Open",
            message = "Free Squad Scrim Night #42 registration is now open. Join before slots fill up!",
            timestamp = "1 hour ago",
            category = "Practice",
            isRead = true
        ),
        NotificationItem(
            id = "n4",
            title = "Tournament Announcement",
            message = "Winter War Championship Season 4 registration deadline extended to 6:00 PM.",
            timestamp = "3 hours ago",
            category = "Tournament",
            isRead = true
        )
    )
}
