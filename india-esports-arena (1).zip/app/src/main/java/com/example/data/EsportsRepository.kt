package com.example.data

import com.example.model.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

object EsportsRepository {

    private val _tournaments = MutableStateFlow<List<Tournament>>(SampleData.initialTournaments)
    val tournaments: StateFlow<List<Tournament>> = _tournaments.asStateFlow()

    private val _matches = MutableStateFlow<List<Match>>(SampleData.initialMatches)
    val matches: StateFlow<List<Match>> = _matches.asStateFlow()

    private val _teams = MutableStateFlow<List<Team>>(SampleData.initialTeams)
    val teams: StateFlow<List<Team>> = _teams.asStateFlow()

    private val _players = MutableStateFlow<List<Player>>(SampleData.initialPlayers)
    val players: StateFlow<List<Player>> = _players.asStateFlow()

    private val _practiceMatches = MutableStateFlow<List<PracticeMatch>>(SampleData.initialPracticeMatches)
    val practiceMatches: StateFlow<List<PracticeMatch>> = _practiceMatches.asStateFlow()

    private val _notifications = MutableStateFlow<List<NotificationItem>>(SampleData.initialNotifications)
    val notifications: StateFlow<List<NotificationItem>> = _notifications.asStateFlow()

    private val _userProfile = MutableStateFlow(UserProfile())
    val userProfile: StateFlow<UserProfile> = _userProfile.asStateFlow()

    // ADMIN: Create Tournament
    fun addTournament(
        title: String,
        game: String,
        format: String,
        teamLimit: Int,
        startDate: String,
        map: String,
        prizePool: String,
        rules: String
    ) {
        val newTournament = Tournament(
            id = "t_" + UUID.randomUUID().toString().take(6),
            title = title,
            game = game,
            format = format,
            teamLimit = teamLimit,
            registeredCount = 1,
            status = "Upcoming",
            startDate = startDate,
            map = map,
            prizePool = prizePool,
            entryFee = "FREE",
            rules = rules,
            registeredTeamNames = mutableListOf("ProGamer_IN Squad")
        )
        _tournaments.value = listOf(newTournament) + _tournaments.value
        sendNotification(
            title = "New Tournament Announced!",
            message = "$title ($format) is now open for registration!",
            category = "Tournament"
        )
    }

    // Register user squad to a tournament
    fun registerTeamForTournament(tournamentId: String, teamName: String): Boolean {
        val currentList = _tournaments.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == tournamentId }
        if (index != -1) {
            val t = currentList[index]
            if (!t.registeredTeamNames.contains(teamName) && t.registeredCount < t.teamLimit) {
                val updatedTeams = t.registeredTeamNames.toMutableList().apply { add(teamName) }
                currentList[index] = t.copy(
                    registeredCount = t.registeredCount + 1,
                    registeredTeamNames = updatedTeams
                )
                _tournaments.value = currentList

                // Update profile
                val profile = _userProfile.value
                if (!profile.registeredTournaments.contains(t.title)) {
                    val updatedRegs = profile.registeredTournaments.toMutableList().apply { add(t.title) }
                    _userProfile.value = profile.copy(registeredTournaments = updatedRegs)
                }

                sendNotification(
                    title = "Registration Confirmed!",
                    message = "Your team '$teamName' successfully registered for ${t.title}.",
                    category = "Tournament"
                )
                return true
            }
        }
        return false
    }

    // ADMIN: Create Match
    fun createMatch(
        tournamentTitle: String,
        matchName: String,
        format: String,
        map: String,
        startTime: String,
        roomId: String,
        roomPassword: String,
        streamUrl: String
    ) {
        val newMatch = Match(
            id = "m_" + UUID.randomUUID().toString().take(6),
            tournamentTitle = tournamentTitle,
            matchName = matchName,
            format = format,
            map = map,
            startTime = startTime,
            status = "Upcoming",
            roomId = roomId,
            roomPassword = roomPassword,
            streamUrl = streamUrl
        )
        _matches.value = listOf(newMatch) + _matches.value
        sendNotification(
            title = "Match Scheduled!",
            message = "$matchName ($map) added to match schedule.",
            category = "Match"
        )
    }

    // ADMIN: Update Match Scores & Standings
    fun updateMatchScores(
        matchId: String,
        results: List<MatchTeamResult>,
        setCompleted: Boolean
    ) {
        val currentList = _matches.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == matchId }
        if (index != -1) {
            val updated = currentList[index].copy(
                results = results,
                status = if (setCompleted) "Completed" else "Live"
            )
            currentList[index] = updated
            _matches.value = currentList

            // Recalculate team points in leaderboards
            recalculateLeaderboards(results)

            sendNotification(
                title = if (setCompleted) "Match Results Published!" else "Live Match Scores Updated",
                message = "${updated.matchName} results are published in Match Details & Leaderboard.",
                category = "Result"
            )
        }
    }

    private fun recalculateLeaderboards(results: List<MatchTeamResult>) {
        val currentTeams = _teams.value.toMutableList()
        results.forEach { res ->
            val teamIdx = currentTeams.indexOfFirst { it.name.equals(res.teamName, ignoreCase = true) }
            if (teamIdx != -1) {
                val t = currentTeams[teamIdx]
                val newWins = t.totalWins + if (res.booyah) 1 else 0
                val newKills = t.totalKills + res.killPoints
                val newPoints = t.totalPoints + res.totalPoints
                currentTeams[teamIdx] = t.copy(
                    matchesPlayed = t.matchesPlayed + 1,
                    totalWins = newWins,
                    totalKills = newKills,
                    totalPoints = newPoints
                )
            }
        }
        // Sort teams by points
        val sortedTeams = currentTeams.sortedByDescending { it.totalPoints }
            .mapIndexed { idx, team -> team.copy(rank = idx + 1) }
        _teams.value = sortedTeams
    }

    // ADMIN: Add Team
    fun addTeam(name: String, tag: String, captainName: String, members: List<String>) {
        val newTeam = Team(
            id = "team_" + UUID.randomUUID().toString().take(6),
            name = name,
            tag = tag,
            captainName = captainName,
            membersCount = members.size,
            winRate = "50%",
            matchesPlayed = 1,
            totalWins = 0,
            totalKills = 10,
            totalPoints = 25,
            rank = _teams.value.size + 1,
            rankChange = "NEW",
            members = members
        )
        _teams.value = _teams.value + newTeam
    }

    // ADMIN: Add Player
    fun addPlayer(name: String, inGameName: String, uid: String, role: String, favoriteTeam: String) {
        val newPlayer = Player(
            id = "p_" + UUID.randomUUID().toString().take(6),
            name = name,
            inGameName = inGameName,
            freeFireUid = uid,
            rankBadge = "Heroic",
            matchesPlayed = 1,
            wins = 0,
            kills = 5,
            kdRatio = 2.5f,
            headshotPercent = "45%",
            role = role,
            favoriteTeam = favoriteTeam,
            rank = _players.value.size + 1
        )
        _players.value = _players.value + newPlayer
    }

    // Practice Scrims
    fun createPracticeMatch(title: String, map: String, mode: String, time: String, slotsMax: Int, roomId: String, roomPassword: String) {
        val newPrac = PracticeMatch(
            id = "prac_" + UUID.randomUUID().toString().take(6),
            title = title,
            map = map,
            mode = mode,
            time = time,
            slotsMax = slotsMax,
            slotsFilled = 1,
            status = "Upcoming",
            roomId = roomId,
            roomPassword = roomPassword,
            hostName = _userProfile.value.username
        )
        _practiceMatches.value = listOf(newPrac) + _practiceMatches.value
        sendNotification(
            title = "Practice Scrim Created",
            message = "$title ($mode) has been published.",
            category = "Practice"
        )
    }

    fun joinPracticeMatch(practiceId: String): Boolean {
        val currentList = _practiceMatches.value.toMutableList()
        val index = currentList.indexOfFirst { it.id == practiceId }
        if (index != -1) {
            val p = currentList[index]
            if (p.slotsFilled < p.slotsMax) {
                currentList[index] = p.copy(slotsFilled = p.slotsFilled + 1)
                _practiceMatches.value = currentList
                sendNotification(
                    title = "Joined Practice Scrim!",
                    message = "You have reserved a slot in ${p.title}. Room ID: ${p.roomId}",
                    category = "Practice"
                )
                return true
            }
        }
        return false
    }

    // Profile update
    fun updateUserProfile(
        username: String,
        inGameName: String,
        freeFireUid: String,
        rankBadge: String,
        favoriteTeam: String
    ) {
        _userProfile.value = _userProfile.value.copy(
            username = username,
            inGameName = inGameName,
            freeFireUid = freeFireUid,
            rankBadge = rankBadge,
            favoriteTeam = favoriteTeam
        )
    }

    // Notifications
    fun sendNotification(title: String, message: String, category: String) {
        val newNotif = NotificationItem(
            id = "n_" + UUID.randomUUID().toString().take(6),
            title = title,
            message = message,
            timestamp = "Just now",
            category = category,
            isRead = false
        )
        _notifications.value = listOf(newNotif) + _notifications.value
    }

    fun markNotificationRead(id: String) {
        _notifications.value = _notifications.value.map {
            if (it.id == id) it.copy(isRead = true) else it
        }
    }

    fun clearNotifications() {
        _notifications.value = emptyList()
    }
}
