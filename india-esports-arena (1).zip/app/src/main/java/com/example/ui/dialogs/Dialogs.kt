package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.*
import com.example.ui.components.StatusBadge
import com.example.ui.components.TagBadge
import com.example.ui.theme.*

@Composable
fun TournamentDetailDialog(
    tournament: Tournament,
    onDismiss: () -> Unit,
    onRegisterClick: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = EsportsSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, FlameRedPrimary),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("tournament_detail_dialog")
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusBadge(status = tournament.status)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(
                    text = tournament.title,
                    color = TextWhite,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Black
                )

                Spacer(modifier = Modifier.height(6.dp))

                Text(
                    text = "${tournament.game} • ${tournament.format} • ${tournament.map}",
                    color = FlameRedPrimary,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )

                Divider(color = EsportsBorder, modifier = Modifier.padding(vertical = 12.dp))

                // Details grid
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    DetailItem(title = "START TIME", value = tournament.startDate)
                    DetailItem(title = "ENTRY FEE", value = tournament.entryFee, highlight = true)
                }

                Spacer(modifier = Modifier.height(10.dp))

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    DetailItem(title = "SLOTS", value = "${tournament.registeredCount} / ${tournament.teamLimit} Teams")
                    DetailItem(title = "REWARD", value = tournament.prizePool)
                }

                Divider(color = EsportsBorder, modifier = Modifier.padding(vertical = 12.dp))

                Text(text = "RULES & FORMAT", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Text(text = tournament.rules, color = TextMuted, fontSize = 12.sp, lineHeight = 18.sp)

                Spacer(modifier = Modifier.height(12.dp))

                Text(text = "REGISTERED SQUADS (${tournament.registeredTeamNames.size})", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    tournament.registeredTeamNames.take(8).forEachIndexed { idx, teamName ->
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Shield, contentDescription = null, tint = AccentGold, modifier = Modifier.size(12.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "${idx + 1}. $teamName", color = TextWhite, fontSize = 12.sp)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = {
                        onDismiss()
                        onRegisterClick()
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FlameRedPrimary),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().testTag("dialog_register_btn"),
                    enabled = tournament.status != "Completed" && tournament.registeredCount < tournament.teamLimit
                ) {
                    Text(text = "REGISTER SQUAD NOW", color = Color.White, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun DetailItem(title: String, value: String, highlight: Boolean = false) {
    Column {
        Text(text = title, color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text(
            text = value,
            color = if (highlight) LiveGreen else TextWhite,
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
fun MatchDetailDialog(
    match: Match,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = EsportsSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, FlameRedPrimary),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("match_detail_dialog")
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    StatusBadge(status = match.status)
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                    }
                }

                Text(text = match.tournamentTitle, color = FlameRedPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                Text(text = match.matchName, color = TextWhite, fontSize = 18.sp, fontWeight = FontWeight.Black)

                Spacer(modifier = Modifier.height(12.dp))

                // Room Credentials Panel
                Surface(
                    color = EsportsCardBg,
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, EsportsBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.LockOpen, contentDescription = null, tint = AccentGold, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = "MATCH ROOM ACCESS", color = AccentGold, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(text = "Room ID: ${match.roomId}", color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                            Text(text = "Pass: ${match.roomPassword}", color = FlameRedPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(text = "MATCH STANDINGS & RESULTS", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))

                if (match.results.isEmpty()) {
                    Text(text = "Match in progress or waiting to be launched by admin.", color = TextMuted, fontSize = 12.sp)
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(EsportsCardBg)
                                .padding(horizontal = 8.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("# TEAM", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(2f))
                            Text("KILLS", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text("PLACE", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text("PTS", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        }

                        match.results.forEach { res ->
                            Surface(
                                color = if (res.booyah) FlameRedPrimary.copy(alpha = 0.15f) else EsportsSurface,
                                border = androidx.compose.foundation.BorderStroke(
                                    0.5.dp,
                                    if (res.booyah) FlameRedPrimary else EsportsBorder
                                ),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 8.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(modifier = Modifier.weight(2f), verticalAlignment = Alignment.CenterVertically) {
                                        if (res.booyah) {
                                            Icon(Icons.Default.EmojiEvents, contentDescription = "Booyah", tint = AccentGold, modifier = Modifier.size(14.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                        }
                                        Text(text = "${res.rank}. ${res.teamName}", color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                    Text(text = "${res.killPoints}", color = TextWhite, fontSize = 12.sp, modifier = Modifier.weight(1f))
                                    Text(text = "${res.placementPoints}", color = TextWhite, fontSize = 12.sp, modifier = Modifier.weight(1f))
                                    Text(text = "${res.totalPoints}", color = AccentGold, fontSize = 12.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = EsportsCardBg),
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = "CLOSE", color = TextWhite)
                }
            }
        }
    }
}

@Composable
fun RegisterTeamDialog(
    tournamentTitle: String,
    onDismiss: () -> Unit,
    onSubmit: (squadName: String) -> Unit
) {
    var squadName by remember { mutableStateOf("India Gladiators") }
    var captainUid by remember { mutableStateOf("88120491") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = EsportsSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, FlameRedPrimary),
            modifier = Modifier.padding(16.dp).testTag("register_team_dialog")
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(text = "JOIN TOURNAMENT", color = FlameRedPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(text = tournamentTitle, color = TextWhite, fontSize = 18.sp, fontWeight = FontWeight.Black)

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = squadName,
                    onValueChange = { squadName = it },
                    label = { Text("Squad / Team Name") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = FlameRedPrimary,
                        unfocusedBorderColor = EsportsBorder,
                        focusedLabelColor = FlameRedPrimary
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("squad_name_input")
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = captainUid,
                    onValueChange = { captainUid = it },
                    label = { Text("Captain Free Fire UID") },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = FlameRedPrimary,
                        unfocusedBorderColor = EsportsBorder,
                        focusedLabelColor = FlameRedPrimary
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("captain_uid_input")
                )

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = {
                        if (squadName.isNotBlank()) {
                            onSubmit(squadName)
                            onDismiss()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FlameRedPrimary),
                    modifier = Modifier.fillMaxWidth().testTag("submit_registration_btn")
                ) {
                    Text(text = "CONFIRM REGISTRATION (FREE)", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
