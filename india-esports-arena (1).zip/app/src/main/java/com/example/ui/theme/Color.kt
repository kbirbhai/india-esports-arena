package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val EsportsDarkBg = Color(0xFF0A0A0A)
val EsportsSurface = Color(0xFF161616)
val EsportsCardBg = Color(0xFF1C1C1C)
val EsportsNavBg = Color(0xFF0F0F0F)
val EsportsBorder = Color(0x1AFFFFFF) // subtle white/10 border
val EsportsBorderSubtle = Color(0x0DFFFFFF) // ultra subtle white/5 border

val FlameRedPrimary = Color(0xFFDC2626)
val FlameRedDark = Color(0xFF991B1B)
val FlameRedGlow = Color(0x33DC2626)

val AccentGold = Color(0xFFF59E0B)
val LiveGreen = Color(0xFF22C55E)
val StatusBlue = Color(0xFF3B82F6)

val TextWhite = Color(0xFFFFFFFF)
val TextMuted = Color(0xFF9CA3AF)
val TextDark = Color(0xFF0A0A0A)

