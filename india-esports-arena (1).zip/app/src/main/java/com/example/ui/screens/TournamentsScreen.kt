package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Tournament
import com.example.ui.components.TournamentCard
import com.example.ui.theme.*

@Composable
fun TournamentsScreen(
    tournaments: List<Tournament>,
    onSelectTournament: (Tournament) -> Unit,
    onRegisterTournament: (Tournament) -> Unit
) {
    var selectedTab by remember { mutableStateOf("All") }
    var searchQuery by remember { mutableStateOf("") }

    val tabs = listOf("All", "Upcoming", "Ongoing", "Completed")

    val filteredTournaments = tournaments.filter { t ->
        val matchesTab = when (selectedTab) {
            "Upcoming" -> t.status.equals("Upcoming", ignoreCase = true)
            "Ongoing" -> t.status.equals("Ongoing", ignoreCase = true) || t.status.equals("Live", ignoreCase = true)
            "Completed" -> t.status.equals("Completed", ignoreCase = true)
            else -> true
        }
        val matchesSearch = t.title.contains(searchQuery, ignoreCase = true) || t.map.contains(searchQuery, ignoreCase = true)
        matchesTab && matchesSearch
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(EsportsDarkBg)
            .padding(horizontal = 16.dp)
            .testTag("tournaments_screen")
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Search Bar
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search Free Fire Tournaments...", color = TextMuted, fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = FlameRedPrimary) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = FlameRedPrimary,
                unfocusedBorderColor = EsportsBorder,
                focusedContainerColor = EsportsSurface,
                unfocusedContainerColor = EsportsSurface,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite
            ),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("tournament_search_input")
        )

        Spacer(modifier = Modifier.height(10.dp))

        // Filter Tabs
        ScrollableTabRow(
            selectedTabIndex = tabs.indexOf(selectedTab).coerceAtLeast(0),
            containerColor = EsportsDarkBg,
            contentColor = FlameRedPrimary,
            edgePadding = 0.dp,
            divider = {}
        ) {
            tabs.forEach { tab ->
                Tab(
                    selected = selectedTab == tab,
                    onClick = { selectedTab = tab },
                    text = {
                        Text(
                            text = tab.uppercase(),
                            fontWeight = if (selectedTab == tab) FontWeight.Black else FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (selectedTab == tab) FlameRedPrimary else TextMuted
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        LazyColumn(
            contentPadding = PaddingValues(bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (filteredTournaments.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No tournaments found for '$selectedTab'",
                            color = TextMuted,
                            fontSize = 13.sp
                        )
                    }
                }
            } else {
                items(filteredTournaments) { tournament ->
                    TournamentCard(
                        tournament = tournament,
                        onClick = { onSelectTournament(tournament) },
                        onRegisterClick = { onRegisterTournament(tournament) }
                    )
                }
            }
        }
    }
}
