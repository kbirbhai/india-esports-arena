package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Player
import com.example.ui.theme.*

@Composable
fun PlayersScreen(
    players: List<Player>,
    onSelectPlayer: (Player) -> Unit
) {
    var searchQuery by remember { mutableStateOf("") }
    val filteredPlayers = players.filter {
        it.inGameName.contains(searchQuery, ignoreCase = true) || it.freeFireUid.contains(searchQuery, ignoreCase = true) || it.name.contains(searchQuery, ignoreCase = true)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(EsportsDarkBg)
            .padding(horizontal = 16.dp)
            .testTag("players_screen")
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
            value = searchQuery,
            onValueChange = { searchQuery = it },
            placeholder = { Text("Search Player by IGN or Free Fire UID...", color = TextMuted, fontSize = 13.sp) },
            leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, tint = FlameRedPrimary) },
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = FlameRedPrimary,
                unfocusedBorderColor = EsportsBorder,
                focusedContainerColor = EsportsSurface,
                unfocusedContainerColor = EsportsSurface,
                focusedTextColor = TextWhite,
                unfocusedTextColor = TextWhite
            ),
            shape = RoundedCornerShape(10.dp),
            modifier = Modifier.fillMaxWidth().testTag("player_search_input")
        )

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            contentPadding = PaddingValues(bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(filteredPlayers) { player ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectPlayer(player) }
                        .testTag("player_card_${player.id}"),
                    colors = CardDefaults.cardColors(containerColor = EsportsSurface),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, EsportsBorder)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(FlameRedPrimary.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = FlameRedPrimary)
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(text = player.inGameName, color = TextWhite, fontSize = 15.sp, fontWeight = FontWeight.Bold)
                                Text(text = "UID: ${player.freeFireUid} • ${player.role}", color = TextMuted, fontSize = 11.sp)
                                Text(text = player.favoriteTeam, color = FlameRedPrimary, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Text(text = player.rankBadge, color = AccentGold, fontSize = 11.sp, fontWeight = FontWeight.Black)
                            Text(text = "K/D: ${player.kdRatio}", color = LiveGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            Text(text = "HS: ${player.headshotPercent}", color = TextMuted, fontSize = 10.sp)
                        }
                    }
                }
            }
        }
    }
}
