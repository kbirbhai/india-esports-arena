package com.example.ui.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.*
import com.example.ui.components.MatchCard
import com.example.ui.components.StatusBadge
import com.example.ui.components.TagBadge
import com.example.ui.components.TournamentCard
import com.example.ui.theme.*

@Composable
fun HomeScreen(
    tournaments: List<Tournament>,
    matches: List<Match>,
    practiceMatches: List<PracticeMatch>,
    topPlayers: List<Player>,
    onSelectTournament: (Tournament) -> Unit,
    onSelectMatch: (Match) -> Unit,
    onRegisterTournament: (Tournament) -> Unit,
    onNavigateSection: (String) -> Unit
) {
    val featuredTournament = tournaments.firstOrNull { it.status == "Ongoing" || it.status == "Upcoming" } ?: tournaments.firstOrNull()
    val upcomingMatchesPreview = matches.filter { it.status == "Upcoming" || it.status == "Live" }.take(3)
    val freePracticePreview = practiceMatches.take(2)

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(EsportsDarkBg)
            .padding(horizontal = 16.dp)
            .testTag("home_screen_column"),
        contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp)
    ) {
        // QUICK NAVIGATION BUTTONS GRID
        item {
            Text(
                text = "QUICK ARENA SECTIONS",
                color = TextWhite,
                fontSize = 13.sp,
                fontWeight = FontWeight.Black,
                letterSpacing = 0.5.sp
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                QuickNavBtn(title = "Tournaments", icon = Icons.Default.EmojiEvents, color = FlameRedPrimary) { onNavigateSection("TOURNAMENTS") }
                QuickNavBtn(title = "Matches", icon = Icons.Default.SportsEsports, color = AccentGold) { onNavigateSection("MATCHES") }
                QuickNavBtn(title = "Leaderboard", icon = Icons.Default.Leaderboard, color = LiveGreen) { onNavigateSection("LEADERBOARD") }
                QuickNavBtn(title = "Practice", icon = Icons.Default.Adjust, color = StatusBlue) { onNavigateSection("PRACTICE") }
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                QuickNavBtn(title = "Teams", icon = Icons.Default.Groups, color = Color(0xFFFF7043)) { onNavigateSection("TEAMS") }
                QuickNavBtn(title = "Players", icon = Icons.Default.Person, color = Color(0xFFAB47BC)) { onNavigateSection("PLAYERS") }
                QuickNavBtn(title = "Profile", icon = Icons.Default.AccountCircle, color = Color(0xFF26A69A)) { onNavigateSection("PROFILE") }
                QuickNavBtn(title = "Admin", icon = Icons.Default.AdminPanelSettings, color = FlameRedPrimary) { onNavigateSection("ADMIN") }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        // FEATURED TOURNAMENT HERO BANNER
        if (featuredTournament != null) {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "FEATURED TOURNAMENT",
                        color = TextWhite,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Black
                    )
                    Text(
                        text = "VIEW ALL",
                        color = FlameRedPrimary,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.clickable { onNavigateSection("TOURNAMENTS") }
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onSelectTournament(featuredTournament) }
                        .testTag("featured_tournament_hero"),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = EsportsSurface),
                    border = androidx.compose.foundation.BorderStroke(1.dp, FlameRedPrimary)
                ) {
                    Box(modifier = Modifier.fillMaxWidth()) {
                        // Banner Image or Gradient
                        val bannerRes = featuredTournament.bannerDrawableRes
                        if (bannerRes != null) {
                            Image(
                                painter = painterResource(id = bannerRes),
                                contentDescription = "Hero Banner",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(160.dp)
                            )
                        } else {
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(160.dp)
                                    .background(
                                        Brush.verticalGradient(
                                            listOf(FlameRedDark, EsportsSurface)
                                        )
                                    )
                            )
                        }

                        // Gradient overlay
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .background(
                                    Brush.verticalGradient(
                                        listOf(Color.Transparent, EsportsSurface.copy(alpha = 0.95f))
                                    )
                                )
                        )

                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(16.dp)
                                .align(Alignment.BottomStart)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                StatusBadge(status = featuredTournament.status)
                                TagBadge(text = "ENTRY: ${featuredTournament.entryFee}", color = LiveGreen)
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = featuredTournament.title,
                                color = TextWhite,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Black
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "${featuredTournament.game} • ${featuredTournament.format} • ${featuredTournament.map}",
                                color = FlameRedPrimary,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = AccentGold, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text(
                                        text = featuredTournament.prizePool,
                                        color = AccentGold,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold
                                    )
                                }
                                Button(
                                    onClick = { onRegisterTournament(featuredTournament) },
                                    colors = ButtonDefaults.buttonColors(containerColor = FlameRedPrimary),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 14.dp, vertical = 4.dp),
                                    modifier = Modifier.height(32.dp)
                                ) {
                                    Text(text = "JOIN FREE", fontSize = 11.sp, fontWeight = FontWeight.Black)
                                }
                            }
                        }
                    }
                }
                Spacer(modifier = Modifier.height(20.dp))
            }
        }

        // UPCOMING / LIVE MATCHES PREVIEW
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "UPCOMING & LIVE MATCHES",
                    color = TextWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "SCHEDULE",
                    color = FlameRedPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { onNavigateSection("MATCHES") }
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        items(upcomingMatchesPreview) { match ->
            MatchCard(match = match, onClick = { onSelectMatch(match) })
        }

        // FREE PRACTICE MATCHES PREVIEW
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "FREE SQUAD PRACTICE SCRIMS",
                    color = TextWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "JOIN SCRIM",
                    color = FlameRedPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { onNavigateSection("PRACTICE") }
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
        }

        items(freePracticePreview) { prac ->
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
                    .clickable { onNavigateSection("PRACTICE") },
                colors = CardDefaults.cardColors(containerColor = EsportsSurface),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, EsportsBorder)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(text = prac.title, color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        Text(text = "${prac.mode} • Map: ${prac.map}", color = TextMuted, fontSize = 11.sp)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(text = "Room ID: ${prac.roomId}", color = AccentGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    StatusBadge(status = prac.status)
                }
            }
        }

        // TOP PLAYERS SPOTLIGHT
        item {
            Spacer(modifier = Modifier.height(20.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TOP COMMUNITY PLAYERS",
                    color = TextWhite,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Black
                )
                Text(
                    text = "RANKINGS",
                    color = FlameRedPrimary,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    modifier = Modifier.clickable { onNavigateSection("LEADERBOARD") }
                )
            }
            Spacer(modifier = Modifier.height(8.dp))

            LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(topPlayers.take(5)) { player ->
                    Card(
                        modifier = Modifier
                            .width(130.dp)
                            .clickable { onNavigateSection("PLAYERS") },
                        colors = CardDefaults.cardColors(containerColor = EsportsSurface),
                        shape = RoundedCornerShape(12.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, EsportsBorder)
                    ) {
                        Column(
                            modifier = Modifier.padding(12.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(CircleShape)
                                    .background(FlameRedPrimary.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = FlameRedPrimary)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = player.inGameName,
                                color = TextWhite,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = player.rankBadge,
                                color = AccentGold,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "K/D ${player.kdRatio}",
                                color = TextMuted,
                                fontSize = 10.sp
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun QuickNavBtn(
    title: String,
    icon: ImageVector,
    color: Color,
    onClick: () -> Unit
) {
    Surface(
        onClick = onClick,
        shape = RoundedCornerShape(10.dp),
        color = EsportsSurface,
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.4f)),
        modifier = Modifier
            .width(82.dp)
            .height(72.dp)
            .testTag("nav_btn_${title.lowercase()}")
    ) {
        Column(
            modifier = Modifier.padding(6.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(imageVector = icon, contentDescription = title, tint = color, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = title,
                color = TextWhite,
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
        }
    }
}
