package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Player
import com.example.model.Team
import com.example.ui.theme.*

@Composable
fun LeaderboardScreen(
    teams: List<Team>,
    players: List<Player>
) {
    var selectedCategory by remember { mutableStateOf("Teams") }
    val categories = listOf("Teams", "Players")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(EsportsDarkBg)
            .padding(horizontal = 16.dp)
            .testTag("leaderboard_screen")
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Category Selector
        TabRow(
            selectedTabIndex = categories.indexOf(selectedCategory),
            containerColor = EsportsDarkBg,
            contentColor = FlameRedPrimary,
            divider = {}
        ) {
            categories.forEach { category ->
                Tab(
                    selected = selectedCategory == category,
                    onClick = { selectedCategory = category },
                    text = {
                        Text(
                            text = category.uppercase() + " RANKINGS",
                            fontWeight = if (selectedCategory == category) FontWeight.Black else FontWeight.Bold,
                            fontSize = 12.sp,
                            color = if (selectedCategory == category) FlameRedPrimary else TextMuted
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (selectedCategory == "Teams") {
            // TEAM LEADERBOARD TABLE
            LazyColumn(
                contentPadding = PaddingValues(bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                // Table Header
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(EsportsSurface)
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("# TEAM", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(2.5f))
                        Text("MP", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text("WINS", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text("KILLS", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text("PTS", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    }
                }

                itemsIndexed(teams) { index, team ->
                    val rankColor = when (index) {
                        0 -> AccentGold
                        1 -> Color(0xFFC0C0C0) // Silver
                        2 -> Color(0xFFCD7F32) // Bronze
                        else -> TextWhite
                    }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("team_rank_${team.id}"),
                        colors = CardDefaults.cardColors(containerColor = if (index == 0) FlameRedPrimary.copy(alpha = 0.12f) else EsportsSurface),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (index == 0) FlameRedPrimary else EsportsBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(modifier = Modifier.weight(2.5f), verticalAlignment = Alignment.CenterVertically) {
                                if (index < 3) {
                                    Icon(
                                        imageVector = Icons.Default.EmojiEvents,
                                        contentDescription = "Trophy",
                                        tint = rankColor,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(4.dp))
                                } else {
                                    Text(
                                        text = "${index + 1}.",
                                        color = TextMuted,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.width(20.dp)
                                    )
                                }
                                Column {
                                    Text(
                                        text = team.name,
                                        color = TextWhite,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "[${team.tag}] • Cpt: ${team.captainName}",
                                        color = TextMuted,
                                        fontSize = 10.sp
                                    )
                                }
                            }

                            Text(text = "${team.matchesPlayed}", color = TextWhite, fontSize = 12.sp, modifier = Modifier.weight(1f))
                            Text(text = "${team.totalWins}", color = LiveGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text(text = "${team.totalKills}", color = TextWhite, fontSize = 12.sp, modifier = Modifier.weight(1f))
                            Text(text = "${team.totalPoints}", color = AccentGold, fontSize = 13.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        } else {
            // PLAYER LEADERBOARD TABLE
            LazyColumn(
                contentPadding = PaddingValues(bottom = 90.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .background(EsportsSurface)
                            .padding(horizontal = 12.dp, vertical = 8.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("# PLAYER", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(2.5f))
                        Text("K/D", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text("HS%", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                        Text("KILLS", color = TextMuted, fontSize = 11.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                    }
                }

                itemsIndexed(players) { index, player ->
                    val rankColor = when (index) {
                        0 -> AccentGold
                        1 -> Color(0xFFC0C0C0)
                        2 -> Color(0xFFCD7F32)
                        else -> TextWhite
                    }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("player_rank_${player.id}"),
                        colors = CardDefaults.cardColors(containerColor = if (index == 0) FlameRedPrimary.copy(alpha = 0.12f) else EsportsSurface),
                        shape = RoundedCornerShape(8.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (index == 0) FlameRedPrimary else EsportsBorder)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(modifier = Modifier.weight(2.5f), verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "${index + 1}.",
                                    color = rankColor,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.width(22.dp)
                                )
                                Column {
                                    Text(
                                        text = player.inGameName,
                                        color = TextWhite,
                                        fontSize = 13.sp,
                                        fontWeight = FontWeight.Bold,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                    Text(
                                        text = "${player.role} • ${player.rankBadge}",
                                        color = FlameRedPrimary,
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }

                            Text(text = "${player.kdRatio}", color = AccentGold, fontSize = 12.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                            Text(text = player.headshotPercent, color = TextWhite, fontSize = 12.sp, modifier = Modifier.weight(1f))
                            Text(text = "${player.kills}", color = LiveGreen, fontSize = 13.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                        }
                    }
                }
            }
        }
    }
}
