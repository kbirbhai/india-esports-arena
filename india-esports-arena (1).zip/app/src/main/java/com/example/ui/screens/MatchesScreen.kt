package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Match
import com.example.ui.components.MatchCard
import com.example.ui.theme.*

@Composable
fun MatchesScreen(
    matches: List<Match>,
    onSelectMatch: (Match) -> Unit
) {
    var selectedTab by remember { mutableStateOf("All") }
    val tabs = listOf("All", "Upcoming", "Live", "Completed")

    val filteredMatches = matches.filter { m ->
        when (selectedTab) {
            "Upcoming" -> m.status.equals("Upcoming", ignoreCase = true)
            "Live" -> m.status.equals("Live", ignoreCase = true)
            "Completed" -> m.status.equals("Completed", ignoreCase = true)
            else -> true
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(EsportsDarkBg)
            .padding(horizontal = 16.dp)
            .testTag("matches_screen")
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Filter Tabs
        TabRow(
            selectedTabIndex = tabs.indexOf(selectedTab).coerceAtLeast(0),
            containerColor = EsportsDarkBg,
            contentColor = FlameRedPrimary,
            divider = {}
        ) {
            tabs.forEach { tab ->
                Tab(
                    selected = selectedTab == tab,
                    onClick = { selectedTab = tab },
                    text = {
                        Text(
                            text = tab.uppercase(),
                            fontWeight = if (selectedTab == tab) FontWeight.Black else FontWeight.Bold,
                            fontSize = 11.sp,
                            color = if (selectedTab == tab) FlameRedPrimary else TextMuted
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        LazyColumn(
            contentPadding = PaddingValues(bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            if (filteredMatches.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No matches scheduled for '$selectedTab'",
                            color = TextMuted,
                            fontSize = 13.sp
                        )
                    }
                }
            } else {
                items(filteredMatches) { match ->
                    MatchCard(match = match, onClick = { onSelectMatch(match) })
                }
            }
        }
    }
}
