package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Adjust
import androidx.compose.material.icons.filled.Group
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.PracticeMatch
import com.example.ui.components.StatusBadge
import com.example.ui.theme.*

@Composable
fun PracticeScreen(
    practiceMatches: List<PracticeMatch>,
    onJoinPractice: (PracticeMatch) -> Unit,
    onCreatePracticeClick: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(EsportsDarkBg)
            .padding(horizontal = 16.dp)
            .testTag("practice_screen")
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = "FREE PRACTICE SCRIMS", color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Black)
                Text(text = "Practice with community squads & test strategies", color = TextMuted, fontSize = 11.sp)
            }

            Button(
                onClick = onCreatePracticeClick,
                colors = ButtonDefaults.buttonColors(containerColor = FlameRedPrimary),
                shape = RoundedCornerShape(8.dp),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                modifier = Modifier.testTag("host_practice_btn")
            ) {
                Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(text = "HOST SCRIM", fontSize = 11.sp, fontWeight = FontWeight.Bold)
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        LazyColumn(
            contentPadding = PaddingValues(bottom = 90.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(practiceMatches) { prac ->
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("practice_card_${prac.id}"),
                    colors = CardDefaults.cardColors(containerColor = EsportsSurface),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, EsportsBorder)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(text = prac.mode, color = FlameRedPrimary, fontSize = 11.sp, fontWeight = FontWeight.Black)
                            StatusBadge(status = prac.status)
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        Text(text = prac.title, color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                        Text(text = "Map: ${prac.map} • Host: ${prac.hostName}", color = TextMuted, fontSize = 11.sp)

                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(text = "Slots: ${prac.slotsFilled} / ${prac.slotsMax}", color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                Text(text = "Room: ${prac.roomId}", color = AccentGold, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                            }

                            Button(
                                onClick = { onJoinPractice(prac) },
                                colors = ButtonDefaults.buttonColors(containerColor = if (prac.slotsFilled >= prac.slotsMax) EsportsBorder else FlameRedPrimary),
                                enabled = prac.slotsFilled < prac.slotsMax,
                                shape = RoundedCornerShape(6.dp),
                                modifier = Modifier.testTag("join_practice_btn_${prac.id}")
                            ) {
                                Text(
                                    text = if (prac.slotsFilled >= prac.slotsMax) "FULL" else "JOIN PRACTICE",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}
