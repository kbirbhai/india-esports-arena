package com.example.ui.dialogs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.theme.*

@Composable
fun CreatePracticeDialog(
    onDismiss: () -> Unit,
    onSubmit: (title: String, map: String, mode: String, time: String, slotsMax: Int, roomId: String, roomPass: String) -> Unit
) {
    var title by remember { mutableStateOf("Free Squad Practice Scrim #12") }
    var map by remember { mutableStateOf("Bermuda") }
    var mode by remember { mutableStateOf("Free Squad Practice") }
    var time by remember { mutableStateOf("Tonight, 9:30 PM IST") }
    var slotsText by remember { mutableStateOf("12") }
    var roomId by remember { mutableStateOf("PRAC-8812") }
    var roomPass by remember { mutableStateOf("1234") }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = EsportsSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, FlameRedPrimary),
            modifier = Modifier.padding(16.dp).testTag("create_practice_dialog")
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(text = "HOST FREE PRACTICE SCRIM", color = FlameRedPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Text(text = "Create Scrim Room", color = TextWhite, fontSize = 18.sp, fontWeight = FontWeight.Black)

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Scrim Title") },
                    modifier = Modifier.fillMaxWidth()
                )

                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = map,
                        onValueChange = { map = it },
                        label = { Text("Map") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = slotsText,
                        onValueChange = { slotsText = it },
                        label = { Text("Slots") },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = roomId,
                        onValueChange = { roomId = it },
                        label = { Text("Room ID") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = roomPass,
                        onValueChange = { roomPass = it },
                        label = { Text("Room Pass") },
                        modifier = Modifier.weight(1f)
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                Button(
                    onClick = {
                        if (title.isNotBlank()) {
                            val slots = slotsText.toIntOrNull() ?: 12
                            onSubmit(title, map, mode, time, slots, roomId, roomPass)
                            onDismiss()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = FlameRedPrimary),
                    modifier = Modifier.fillMaxWidth().testTag("submit_practice_btn")
                ) {
                    Text(text = "HOST SCRIM & SHARE ROOM ID", fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
