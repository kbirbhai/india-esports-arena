package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable

private val DarkEsportsColorScheme = darkColorScheme(
    primary = FlameRedPrimary,
    onPrimary = TextWhite,
    primaryContainer = FlameRedDark,
    onPrimaryContainer = TextWhite,
    secondary = AccentGold,
    onSecondary = TextDark,
    background = EsportsDarkBg,
    onBackground = TextWhite,
    surface = EsportsSurface,
    onSurface = TextWhite,
    surfaceVariant = EsportsCardBg,
    onSurfaceVariant = TextMuted,
    outline = EsportsBorder
)

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkEsportsColorScheme,
        typography = Typography,
        content = content
    )
}

