package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Save
import androidx.compose.material.icons.filled.Shield
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.UserProfile
import com.example.ui.dialogs.StatBox
import com.example.ui.theme.*

@Composable
fun ProfileScreen(
    userProfile: UserProfile,
    onSaveProfile: (username: String, inGameName: String, uid: String, badge: String, favTeam: String) -> Unit
) {
    var isEditing by remember { mutableStateOf(false) }

    var username by remember(userProfile) { mutableStateOf(userProfile.username) }
    var inGameName by remember(userProfile) { mutableStateOf(userProfile.inGameName) }
    var freeFireUid by remember(userProfile) { mutableStateOf(userProfile.freeFireUid) }
    var rankBadge by remember(userProfile) { mutableStateOf(userProfile.rankBadge) }
    var favoriteTeam by remember(userProfile) { mutableStateOf(userProfile.favoriteTeam) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(EsportsDarkBg)
            .padding(horizontal = 16.dp)
            .verticalScroll(rememberScrollState())
            .testTag("profile_screen"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(16.dp))

        // Profile Avatar Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = EsportsSurface),
            shape = RoundedCornerShape(16.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, FlameRedPrimary)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(FlameRedPrimary),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.Person, contentDescription = null, tint = Color.White, modifier = Modifier.size(36.dp))
                }

                Spacer(modifier = Modifier.height(10.dp))

                Text(text = userProfile.username, color = TextWhite, fontSize = 20.sp, fontWeight = FontWeight.Black)
                Text(text = "IGN: ${userProfile.inGameName} • UID: ${userProfile.freeFireUid}", color = TextMuted, fontSize = 12.sp)

                Spacer(modifier = Modifier.height(6.dp))

                Surface(
                    color = AccentGold.copy(alpha = 0.2f),
                    shape = RoundedCornerShape(4.dp),
                    border = androidx.compose.foundation.BorderStroke(0.5.dp, AccentGold)
                ) {
                    Text(
                        text = userProfile.rankBadge.uppercase(),
                        color = AccentGold,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // STATS SUMMARY CARD
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = EsportsSurface),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, EsportsBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "PLAYER PERFORMANCE STATS", color = FlameRedPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    StatBox(title = "MATCHES", value = userProfile.matchesPlayed.toString())
                    StatBox(title = "WINS", value = userProfile.totalWins.toString())
                    StatBox(title = "KILLS", value = userProfile.totalKills.toString())
                    StatBox(title = "HEADSHOT %", value = userProfile.headshotPercent)
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // REGISTERED TOURNAMENTS
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = EsportsSurface),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, EsportsBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Text(text = "REGISTERED TOURNAMENTS", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                if (userProfile.registeredTournaments.isEmpty()) {
                    Text(text = "No active tournament registrations.", color = TextMuted, fontSize = 12.sp)
                } else {
                    userProfile.registeredTournaments.forEach { tour ->
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 4.dp)) {
                            Icon(Icons.Default.Shield, contentDescription = null, tint = LiveGreen, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(text = tour, color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // EDIT PROFILE CARD
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = EsportsSurface),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, EsportsBorder)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(text = "EDIT PROFILE DETAILS", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    IconButton(onClick = { isEditing = !isEditing }) {
                        Icon(if (isEditing) Icons.Default.Save else Icons.Default.Edit, contentDescription = "Edit", tint = FlameRedPrimary)
                    }
                }

                if (isEditing) {
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = username,
                        onValueChange = { username = it },
                        label = { Text("App Username") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = inGameName,
                        onValueChange = { inGameName = it },
                        label = { Text("Free Fire IGN") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = freeFireUid,
                        onValueChange = { freeFireUid = it },
                        label = { Text("Free Fire UID") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = favoriteTeam,
                        onValueChange = { favoriteTeam = it },
                        label = { Text("Favorite Team") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            onSaveProfile(username, inGameName, freeFireUid, rankBadge, favoriteTeam)
                            isEditing = false
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = FlameRedPrimary),
                        modifier = Modifier.fillMaxWidth().testTag("save_profile_btn")
                    ) {
                        Text(text = "SAVE CHANGES", fontWeight = FontWeight.Bold)
                    }
                } else {
                    Text(text = "Tap pencil icon above to edit your IGN, UID & details.", color = TextMuted, fontSize = 12.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(100.dp))
    }
}
