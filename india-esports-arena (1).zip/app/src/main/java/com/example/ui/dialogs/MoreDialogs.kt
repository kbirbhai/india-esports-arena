package com.example.ui.dialogs

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.Player
import com.example.model.Team
import com.example.ui.theme.*

@Composable
fun TeamDetailDialog(
    team: Team,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = EsportsSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, FlameRedPrimary),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("team_detail_dialog")
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = FlameRedPrimary,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = "TAG: [${team.tag}]",
                            color = Color.White,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Black,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(text = team.name, color = TextWhite, fontSize = 22.sp, fontWeight = FontWeight.Black)
                Text(text = "Captain: ${team.captainName}", color = AccentGold, fontSize = 13.sp, fontWeight = FontWeight.Bold)

                Divider(color = EsportsBorder, modifier = Modifier.padding(vertical = 12.dp))

                // Stats Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    StatBox(title = "RANK", value = "#${team.rank}")
                    StatBox(title = "WIN RATE", value = team.winRate)
                    StatBox(title = "MATCHES", value = team.matchesPlayed.toString())
                    StatBox(title = "KILLS", value = team.totalKills.toString())
                }

                Divider(color = EsportsBorder, modifier = Modifier.padding(vertical = 12.dp))

                Text(text = "ACTIVE ROSTER", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    team.members.forEach { member ->
                        Surface(
                            color = EsportsCardBg,
                            shape = RoundedCornerShape(6.dp),
                            border = androidx.compose.foundation.BorderStroke(0.5.dp, EsportsBorder)
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Person, contentDescription = null, tint = FlameRedPrimary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(text = member, color = TextWhite, fontSize = 13.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Text(text = "RECENT ACHIEVEMENTS", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(6.dp))
                team.matchHistorySummary.forEach { achievement ->
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.padding(vertical = 2.dp)) {
                        Icon(Icons.Default.EmojiEvents, contentDescription = null, tint = AccentGold, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = achievement, color = TextMuted, fontSize = 12.sp)
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = EsportsCardBg),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = "CLOSE", color = TextWhite)
                }
            }
        }
    }
}

@Composable
fun PlayerDetailDialog(
    player: Player,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = EsportsSurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, FlameRedPrimary),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("player_detail_dialog")
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState())
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = AccentGold.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(4.dp),
                        border = androidx.compose.foundation.BorderStroke(0.5.dp, AccentGold)
                    ) {
                        Text(
                            text = player.rankBadge.uppercase(),
                            color = AccentGold,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }
                    IconButton(onClick = onDismiss) {
                        Icon(Icons.Default.Close, contentDescription = "Close", tint = TextMuted)
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                Text(text = player.inGameName, color = TextWhite, fontSize = 22.sp, fontWeight = FontWeight.Black)
                Text(text = "Real Name: ${player.name} • UID: ${player.freeFireUid}", color = TextMuted, fontSize = 12.sp)

                Spacer(modifier = Modifier.height(8.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.GpsFixed, contentDescription = null, tint = FlameRedPrimary, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(text = "Role: ${player.role}", color = FlameRedPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                }

                Divider(color = EsportsBorder, modifier = Modifier.padding(vertical = 12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceAround
                ) {
                    StatBox(title = "K/D RATIO", value = player.kdRatio.toString())
                    StatBox(title = "HEADSHOT %", value = player.headshotPercent)
                    StatBox(title = "KILLS", value = player.kills.toString())
                    StatBox(title = "WINS", value = player.wins.toString())
                }

                Spacer(modifier = Modifier.height(14.dp))

                Surface(
                    color = EsportsCardBg,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = AccentGold)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(text = "FAVOURITE TEAM", color = TextMuted, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            Text(text = player.favoriteTeam, color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(20.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = EsportsCardBg),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(text = "CLOSE PROFILE", color = TextWhite)
                }
            }
        }
    }
}

@Composable
fun StatBox(title: String, value: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(text = value, color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Black)
        Text(text = title, color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Bold)
    }
}
