package com.example.ui.navigation

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.*

data class NavItem(
    val route: String,
    val title: String,
    val activeIcon: ImageVector,
    val inactiveIcon: ImageVector
)

val primaryNavItems = listOf(
    NavItem("HOME", "Home", Icons.Default.Home, Icons.Outlined.Home),
    NavItem("TOURNAMENTS", "Tournaments", Icons.Default.EmojiEvents, Icons.Outlined.EmojiEvents),
    NavItem("MATCHES", "Matches", Icons.Default.SportsEsports, Icons.Outlined.SportsEsports),
    NavItem("LEADERBOARD", "Ranks", Icons.Default.Leaderboard, Icons.Outlined.Leaderboard),
    NavItem("PRACTICE", "Practice", Icons.Default.Adjust, Icons.Outlined.Adjust),
    NavItem("ADMIN", "Admin", Icons.Default.AdminPanelSettings, Icons.Outlined.AdminPanelSettings)
)

@Composable
fun EsportsBottomNavigationBar(
    currentRoute: String,
    onNavigate: (String) -> Unit
) {
    Surface(
        color = EsportsSurface,
        modifier = Modifier.fillMaxWidth(),
        shadowElevation = 8.dp,
        border = androidx.compose.foundation.BorderStroke(0.5.dp, EsportsBorder)
    ) {
        NavigationBar(
            containerColor = EsportsSurface,
            contentColor = TextWhite,
            modifier = Modifier.windowInsetsPadding(WindowInsets.navigationBars)
        ) {
            primaryNavItems.forEach { item ->
                val isSelected = currentRoute == item.route
                NavigationBarItem(
                    selected = isSelected,
                    onClick = { onNavigate(item.route) },
                    icon = {
                        Icon(
                            imageVector = if (isSelected) item.activeIcon else item.inactiveIcon,
                            contentDescription = item.title,
                            tint = if (isSelected) FlameRedPrimary else TextMuted,
                            modifier = Modifier.size(20.dp)
                        )
                    },
                    label = {
                        Text(
                            text = item.title,
                            color = if (isSelected) FlameRedPrimary else TextMuted,
                            fontSize = 10.sp,
                            fontWeight = if (isSelected) FontWeight.Black else FontWeight.Medium
                        )
                    },
                    colors = NavigationBarItemDefaults.colors(
                        indicatorColor = FlameRedPrimary.copy(alpha = 0.15f)
                    ),
                    modifier = Modifier.testTag("nav_item_${item.route.lowercase()}")
                )
            }
        }
    }
}
