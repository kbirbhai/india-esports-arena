package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AdminPanelSettings
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.SportsEsports
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.Match
import com.example.model.MatchTeamResult
import com.example.model.Tournament
import com.example.ui.theme.*

@Composable
fun AdminScreen(
    tournaments: List<Tournament>,
    matches: List<Match>,
    onCreateTournament: (title: String, game: String, format: String, slots: Int, date: String, map: String, reward: String, rules: String) -> Unit,
    onCreateMatch: (tourTitle: String, matchName: String, format: String, map: String, time: String, roomId: String, roomPass: String, streamUrl: String) -> Unit,
    onUpdateScores: (matchId: String, results: List<MatchTeamResult>, setCompleted: Boolean) -> Unit,
    onAddTeam: (name: String, tag: String, captain: String) -> Unit,
    onBroadcast: (title: String, message: String, category: String) -> Unit
) {
    var selectedSection by remember { mutableStateOf("Create Tournament") }
    val sections = listOf("Create Tournament", "Create Match", "Update Scores", "Add Team", "Broadcast")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(EsportsDarkBg)
            .padding(horizontal = 16.dp)
            .testTag("admin_screen")
    ) {
        Spacer(modifier = Modifier.height(10.dp))

        // Admin Header
        Surface(
            color = FlameRedPrimary.copy(alpha = 0.15f),
            shape = RoundedCornerShape(10.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, FlameRedPrimary),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(
                modifier = Modifier.padding(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = FlameRedPrimary, modifier = Modifier.size(24.dp))
                Spacer(modifier = Modifier.width(10.dp))
                Column {
                    Text(text = "TOURNAMENT MANAGER CONSOLE", color = TextWhite, fontSize = 14.sp, fontWeight = FontWeight.Black)
                    Text(text = "Full control to host scrims, generate room IDs & update standings", color = TextMuted, fontSize = 11.sp)
                }
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Navigation Tabs for Admin
        ScrollableTabRow(
            selectedTabIndex = sections.indexOf(selectedSection).coerceAtLeast(0),
            containerColor = EsportsDarkBg,
            contentColor = FlameRedPrimary,
            edgePadding = 0.dp,
            divider = {}
        ) {
            sections.forEach { sec ->
                Tab(
                    selected = selectedSection == sec,
                    onClick = { selectedSection = sec },
                    text = {
                        Text(
                            text = sec.uppercase(),
                            fontWeight = if (selectedSection == sec) FontWeight.Black else FontWeight.Bold,
                            fontSize = 11.sp,
                            color = if (selectedSection == sec) FlameRedPrimary else TextMuted
                        )
                    }
                )
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        Column(
            modifier = Modifier
                .fillMaxSize()
                .verticalScroll(rememberScrollState())
                .padding(bottom = 90.dp)
        ) {
            when (selectedSection) {
                "Create Tournament" -> CreateTournamentForm(onCreateTournament)
                "Create Match" -> CreateMatchForm(tournaments, onCreateMatch)
                "Update Scores" -> UpdateScoresForm(matches, onUpdateScores)
                "Add Team" -> AddTeamForm(onAddTeam)
                "Broadcast" -> BroadcastForm(onBroadcast)
            }
        }
    }
}

@Composable
fun CreateTournamentForm(
    onCreateTournament: (title: String, game: String, format: String, slots: Int, date: String, map: String, reward: String, rules: String) -> Unit
) {
    var title by remember { mutableStateOf("Free Fire India Showdown Season 1") }
    var game by remember { mutableStateOf("Free Fire MAX") }
    var format by remember { mutableStateOf("Squad") }
    var slotsText by remember { mutableStateOf("48") }
    var startDate by remember { mutableStateOf("Tonight, 8:00 PM IST") }
    var map by remember { mutableStateOf("Bermuda") }
    var prizePool by remember { mutableStateOf("Champion Trophy & Hall of Fame") }
    var rules by remember { mutableStateOf("Standard eSports 4-player squad rules. Emulator strictly prohibited.") }
    var showSuccessMsg by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = EsportsSurface),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, EsportsBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "CREATE NEW TOURNAMENT", color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Tournament Title") }, modifier = Modifier.fillMaxWidth().testTag("admin_tour_title_input"))
            Spacer(modifier = Modifier.height(8.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = format, onValueChange = { format = it }, label = { Text("Format (Squad/Duo/Solo)") }, modifier = Modifier.weight(1f))
                OutlinedTextField(value = slotsText, onValueChange = { slotsText = it }, label = { Text("Team Limit") }, modifier = Modifier.weight(1f))
            }
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(value = startDate, onValueChange = { startDate = it }, label = { Text("Start Date & Time") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(value = map, onValueChange = { map = it }, label = { Text("Map (Bermuda/Purgatory/Kalahari)") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(value = prizePool, onValueChange = { prizePool = it }, label = { Text("Prize / Trophy") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(value = rules, onValueChange = { rules = it }, label = { Text("Tournament Rules") }, modifier = Modifier.fillMaxWidth(), minLines = 2)

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        val slots = slotsText.toIntOrNull() ?: 48
                        onCreateTournament(title, game, format, slots, startDate, map, prizePool, rules)
                        showSuccessMsg = true
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = FlameRedPrimary),
                modifier = Modifier.fillMaxWidth().testTag("publish_tournament_btn")
            ) {
                Text(text = "PUBLISH TOURNAMENT", fontWeight = FontWeight.Bold)
            }

            if (showSuccessMsg) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "✓ Tournament created and published live!", color = LiveGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun CreateMatchForm(
    tournaments: List<Tournament>,
    onCreateMatch: (tourTitle: String, matchName: String, format: String, map: String, time: String, roomId: String, roomPass: String, streamUrl: String) -> Unit
) {
    var tourTitle by remember { mutableStateOf(tournaments.firstOrNull()?.title ?: "Free Fire India Cup 2026") }
    var matchName by remember { mutableStateOf("Match 3 - Purgatory Showdown") }
    var format by remember { mutableStateOf("Squad") }
    var map by remember { mutableStateOf("Purgatory") }
    var time by remember { mutableStateOf("Today, 9:15 PM IST") }
    var roomId by remember { mutableStateOf("ROOM-FF881") }
    var roomPass by remember { mutableStateOf("778811") }
    var streamUrl by remember { mutableStateOf("https://youtube.com/live/freefireindia") }
    var showSuccessMsg by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = EsportsSurface),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, EsportsBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "SCHEDULE MATCH & SET ROOM CREDENTIALS", color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(value = tourTitle, onValueChange = { tourTitle = it }, label = { Text("Parent Tournament Title") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(value = matchName, onValueChange = { matchName = it }, label = { Text("Match Name") }, modifier = Modifier.fillMaxWidth().testTag("admin_match_name_input"))
            Spacer(modifier = Modifier.height(8.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = map, onValueChange = { map = it }, label = { Text("Map") }, modifier = Modifier.weight(1f))
                OutlinedTextField(value = time, onValueChange = { time = it }, label = { Text("Start Time") }, modifier = Modifier.weight(1f))
            }
            Spacer(modifier = Modifier.height(8.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = roomId, onValueChange = { roomId = it }, label = { Text("Room ID") }, modifier = Modifier.weight(1f).testTag("admin_room_id_input"))
                OutlinedTextField(value = roomPass, onValueChange = { roomPass = it }, label = { Text("Room Password") }, modifier = Modifier.weight(1f).testTag("admin_room_pass_input"))
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    if (matchName.isNotBlank()) {
                        onCreateMatch(tourTitle, matchName, format, map, time, roomId, roomPass, streamUrl)
                        showSuccessMsg = true
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = FlameRedPrimary),
                modifier = Modifier.fillMaxWidth().testTag("publish_match_btn")
            ) {
                Text(text = "SCHEDULE & PUBLISH ROOM ID", fontWeight = FontWeight.Bold)
            }

            if (showSuccessMsg) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "✓ Match scheduled! Room credentials unlocked for registered teams.", color = LiveGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun UpdateScoresForm(
    matches: List<Match>,
    onUpdateScores: (matchId: String, results: List<MatchTeamResult>, setCompleted: Boolean) -> Unit
) {
    val selectedMatch = matches.firstOrNull() ?: return
    var team1Name by remember { mutableStateOf("Total Gaming eSports") }
    var team1Kills by remember { mutableStateOf("12") }
    var team1PlacePts by remember { mutableStateOf("12") }

    var team2Name by remember { mutableStateOf("Orangutan Esports") }
    var team2Kills by remember { mutableStateOf("8") }
    var team2PlacePts by remember { mutableStateOf("9") }

    var showSuccessMsg by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = EsportsSurface),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, EsportsBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "ENTER MATCH RESULTS & UPDATE LEADERBOARD", color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Text(text = "Selected Match: ${selectedMatch.matchName}", color = FlameRedPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)

            Spacer(modifier = Modifier.height(12.dp))

            Text(text = "1ST PLACE (BOOYAH!)", color = AccentGold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            OutlinedTextField(value = team1Name, onValueChange = { team1Name = it }, label = { Text("Winning Team Name") }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = team1Kills, onValueChange = { team1Kills = it }, label = { Text("Kill Points") }, modifier = Modifier.weight(1f))
                OutlinedTextField(value = team1PlacePts, onValueChange = { team1PlacePts = it }, label = { Text("Placement Points") }, modifier = Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(text = "2ND PLACE", color = TextWhite, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            OutlinedTextField(value = team2Name, onValueChange = { team2Name = it }, label = { Text("2nd Team Name") }, modifier = Modifier.fillMaxWidth())
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(value = team2Kills, onValueChange = { team2Kills = it }, label = { Text("Kill Points") }, modifier = Modifier.weight(1f))
                OutlinedTextField(value = team2PlacePts, onValueChange = { team2PlacePts = it }, label = { Text("Placement Points") }, modifier = Modifier.weight(1f))
            }

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    val r1 = MatchTeamResult(1, team1Name, team1Kills.toIntOrNull() ?: 12, team1PlacePts.toIntOrNull() ?: 12, booyah = true)
                    val r2 = MatchTeamResult(2, team2Name, team2Kills.toIntOrNull() ?: 8, team2PlacePts.toIntOrNull() ?: 9, booyah = false)
                    onUpdateScores(selectedMatch.id, listOf(r1, r2), true)
                    showSuccessMsg = true
                },
                colors = ButtonDefaults.buttonColors(containerColor = FlameRedPrimary),
                modifier = Modifier.fillMaxWidth().testTag("save_scores_btn")
            ) {
                Text(text = "PUBLISH MATCH RESULTS & LEADERBOARD", fontWeight = FontWeight.Bold)
            }

            if (showSuccessMsg) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "✓ Results saved! Overall leaderboards recalculated automatically.", color = LiveGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun AddTeamForm(onAddTeam: (name: String, tag: String, captain: String) -> Unit) {
    var name by remember { mutableStateOf("Warriors India") }
    var tag by remember { mutableStateOf("WIN") }
    var captain by remember { mutableStateOf("Pro_Captain") }
    var showSuccessMsg by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = EsportsSurface),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, EsportsBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "REGISTER NEW SQUAD / TEAM", color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(value = name, onValueChange = { name = it }, label = { Text("Team Name") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(value = tag, onValueChange = { tag = it }, label = { Text("Team Tag (e.g. TG, OG)") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(value = captain, onValueChange = { captain = it }, label = { Text("Captain Name") }, modifier = Modifier.fillMaxWidth())

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    if (name.isNotBlank()) {
                        onAddTeam(name, tag, captain)
                        showSuccessMsg = true
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = FlameRedPrimary),
                modifier = Modifier.fillMaxWidth().testTag("add_team_btn")
            ) {
                Text(text = "ADD TEAM TO ARENA", fontWeight = FontWeight.Bold)
            }

            if (showSuccessMsg) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "✓ Team registered in community database!", color = LiveGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
fun BroadcastForm(onBroadcast: (title: String, message: String, category: String) -> Unit) {
    var title by remember { mutableStateOf("Free Fire India Cup Final Scrims!") }
    var message by remember { mutableStateOf("Room ID for Match 2 will be posted in 15 mins. Get your squads ready!") }
    var category by remember { mutableStateOf("Match") }
    var showSuccessMsg by remember { mutableStateOf(false) }

    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = EsportsSurface),
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, EsportsBorder)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(text = "BROADCAST COMMUNITY NOTIFICATION", color = TextWhite, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            Spacer(modifier = Modifier.height(12.dp))

            OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("Notification Title") }, modifier = Modifier.fillMaxWidth())
            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(value = message, onValueChange = { message = it }, label = { Text("Announcement Message") }, modifier = Modifier.fillMaxWidth(), minLines = 2)

            Spacer(modifier = Modifier.height(16.dp))

            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onBroadcast(title, message, category)
                        showSuccessMsg = true
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = FlameRedPrimary),
                modifier = Modifier.fillMaxWidth().testTag("send_broadcast_btn")
            ) {
                Icon(Icons.Default.Campaign, contentDescription = null)
                Spacer(modifier = Modifier.width(6.dp))
                Text(text = "SEND COMMUNITY PUSH ALERT", fontWeight = FontWeight.Bold)
            }

            if (showSuccessMsg) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = "✓ Push alert sent to all players in Notifications tab!", color = LiveGreen, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}
